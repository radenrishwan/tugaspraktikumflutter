# Tugas Praktikum 6

![soal](../assets/tugaspraktikum6/soal.png)

### Nama Kelompok
1. Raden Mohamad Rishwan
2. Reza Zulfikri

### Pembahasan
Aplikasi yang kami buat yaitu aplikasi sederhana untuk menyimpan sebuah note.

#### Features
1. Dark Mode
2. Clean and Simple UI

#### Tech Stack
1. Flutter
2. Provider
3. SQFLite
4. Shared Preferences

#### Screenshots

<img src="../assets/tugaspraktikum6/2.png" height="500" style="margin: 10px">
<img src="../assets/tugaspraktikum6/1.png" height="500" style="margin: 10px">
<img src="../assets/tugaspraktikum6/3.png" height="500" style="margin: 10px">
<img src="../assets/tugaspraktikum6/4.png" height="500" style="margin: 10px">
<img src="../assets/tugaspraktikum6/6.png" height="500" style="margin: 10px">
<img src="../assets/tugaspraktikum6/5.png" height="500" style="margin: 10px">