enum NoteStatus { preview, edit }
