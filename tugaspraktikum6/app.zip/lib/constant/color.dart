import 'package:flutter/material.dart';

const kPrimaryColor = Colors.teal;
var kSecondaryColor = Colors.lightBlueAccent.shade400;
